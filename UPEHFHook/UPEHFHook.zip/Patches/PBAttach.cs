﻿using BepInEx.Logging;
using JetBrains.Annotations;
using Spine;
using Spine.Unity;
using Spine.Unity.AttachmentTools;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using UnityEngine;


namespace UPEHFHook.Patches
{
    class PBAttach
    {
        public class SendSkeletonAndPart : MonoBehaviour
        {
            public static SendSkeletonAndPart Instance { get; private set; }
            private bool reverse = false;
            public CommonStates activeCommon;
            private SexManager sexM;
            SkeletonAnimation skeletonNative;
            internal ManualLogSource mls;

            private void Awake()
            {
                if (Instance != null && Instance != this)
                {
                    Destroy(gameObject);
                    return;
                }
                Instance = this;
                DontDestroyOnLoad(gameObject);
                mls = BepInEx.Logging.Logger.CreateLogSource("Ex.MadIslandUPE");
                mls.LogInfo("Mad Island Universal Pregnancy Enabler");

                mls.LogInfo("SendSkeletonAndPart singleton instance created.");
                FindPlayerCommonState();
            }

            private IEnumerator FindPlayerCommonState()
            {
                yield return new WaitForSeconds(1f);
                activeCommon = UnityEngine.Object.FindObjectOfType<CommonStates>(true);
                if (activeCommon != null && activeCommon.gameObject.CompareTag("Player"))
                {
                    mls.LogInfo("Player's CommonState successfully assigned.");
                }
                else
                {
                    mls.LogError("Player's CommonState could not be assigned. Player object with CommonStates not found.");
                }
            }
            public void Update()
            {
                if (Input.GetKeyDown(KeyCode.F4))
                {
                    bool reverse = new bool();
                    reverse = !reverse;
                    CoroutineHelper.Instance.StartCoroutine(Looping_Update(reverse));
                }
            }

            private IEnumerator Looping_Update(bool stop)
            {
                mls.LogInfo($"stop : {stop}");
                while (!stop)
                {
                    ApplyCustomClothToPlayer(true);
                    yield return new WaitForSeconds(3f);
                }
            }
            public void SkelGetter()
            {
                if (sexM == null)
                {
                    sexM = FindObjectOfType<SexManager>();
                    //for example the variable of the skeletonanimation is named  "anim" like in commonstate
                    //optimally you want a dictionnary of skeletonanimations but we will keep it simple 
                    skeletonNative = sexM.GetComponent<SkeletonAnimation>(); // we get the skeletonanimation of the native in the sexmanager (hypothetical)
                    if (sexM == null)
                        mls.LogInfo("SkeletonNative is null.");
                }
            }

            void ApplyCustomClothToPlayer(bool looping)
            {
                if (looping)
                    mls.LogInfo("Part updated");

                if (activeCommon == null)
                {
                    Debug.LogError("Player's CommonState is null.");
                    return;
                }

                SkeletonAnimation skeletonAnim = skeletonNative;

                if (skeletonAnim == null)
                {
                    Debug.LogError("SkeletonAnimation component not found on the player's CommonStates.");
                    return;
                }
                List<string> partsToApply = new List<string> { "Body" };
                SkinManager.Instance.ApplyModSkin("body_preg", "all", skeletonAnim, partsToApply, true);
                mls.LogInfo(partsToApply);
            }

            /*public void BellyApply()
            {
                while (activeCommon.anim.skeleton.GetAttachment("body_preg", "body_preg") == null)
                {
                    ApplyCustomClothToPlayer(true);
                    return;
                }
            
            }*/


        }
    }
}

