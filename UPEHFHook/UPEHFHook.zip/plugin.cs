﻿using BepInEx.Logging;
using BepInEx;
using HarmonyLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Spine.Unity;
using UnityEngine;
using Spine;
using UPEHFHook.Patches;

namespace UPEHFHook
{
    [BepInPlugin(modGUID, modName, modVersion)]
    public class UPEHFBase : BaseUnityPlugin
    {
        private const string modGUID = "Ex.MadIslandUPE";
        private const string modName = "Ex Universal Pregnancy Enabler";
        private const string modVersion = "1.0.0";

        private readonly Harmony harmony = new Harmony(modGUID);
        internal ManualLogSource mls;


        void Awake()
        {
            mls = BepInEx.Logging.Logger.CreateLogSource(modGUID);
            mls.LogInfo("Mad Island Universal Pregnancy Enabler");

            harmony.PatchAll(typeof(UPEHFBase));
            harmony.PatchAll(typeof(GetPreg));
            harmony.PatchAll(typeof(PBAttach));

            mls.LogInfo("Fill them up.");

            var componentsToInitialize = new List<Type>
            {
                typeof(SkinManager),
                typeof(PBAttach.SendSkeletonAndPart)
            };

            foreach (var componentType in componentsToInitialize)
            {
                if (FindObjectOfType(componentType) == null)
                {
                    InstantiateSingleton(componentType);
                }
            }
        }

        private void InstantiateSingleton(Type type)
        {
            GameObject obj = new GameObject(type.Name);
            obj.AddComponent(type);
            DontDestroyOnLoad(obj);
            mls.LogInfo($"{type.Name} instantiated.");
        }
    }
}
